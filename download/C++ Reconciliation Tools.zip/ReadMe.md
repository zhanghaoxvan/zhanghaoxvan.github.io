# $ReadMe$ - `C++ Reconciliation Tools`

`C++ Reconciliation Tools`由$zhanghaoxvan$制作，是一个适用于`C/C++`的工具包。它拥有一些$和平工具$，避免此种情况发生:

```
int *p
int* p
int * p
int*p
我：该选哪个啊？
```

注：如果真要选择的话，请选择`int *p`，防止误读

## $Contact$

$QQ$: 3592114583

$Email$: 3592114583@qq.com

**_联系时回复：CRT + GitHub开源网址 + 邮箱地址即可_**

如：

```
CRT github.com/example example@qq.com
```

## $Reply$

$zhanghaoxvan$收到后将会审核，审核成功后将会给您发邮件，如：

From: 3591114583@qq.com

To:   example@qq.com

```
谢谢您的GitHub开源网址！
您的头文件将会被添加如下内容并改成 您的类名.h ：
// Project:   C++ Reconciliation Tools
// File:      您的类名.h
// Copyright: TinySoftware, Inc.
// Author:    example@qq.com
您的代码...
```

